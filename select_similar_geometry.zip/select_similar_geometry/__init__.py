bl_info = {
    "name": "Select Similar Geometry (by Percentage)",
    "author": "Juan Romero",
    "version": (1, 2, 1),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Select > Select Similar Geometry",
    "description": "Selects objects whose geometry matches the active one above a given percentage",
    "category": "Object",
}

import bpy
from mathutils import kdtree

# Store keymaps so they can be removed when the add-on is disabled
addon_keymaps = []


def get_world_vertices(obj):
    """Return the list of vertex coordinates in world space."""
    m = obj.matrix_world
    return [m @ v.co for v in obj.data.vertices]


def count_vertex_matches(ref_verts, target_verts, tol):
    """
    Return how many vertices in ref_verts have a matching vertex in target_verts
    within the tolerance tol. Each target vertex can only be used once.
    """
    if not ref_verts or not target_verts:
        return 0

    tree = kdtree.KDTree(len(target_verts))
    for i, co in enumerate(target_verts):
        tree.insert(co, i)
    tree.balance()

    used = set()
    matches = 0

    for co in ref_verts:
        _, index, dist = tree.find(co)
        if index is not None and dist <= tol and index not in used:
            matches += 1
            used.add(index)

    return matches


class OBJECT_OT_select_similar_geometry(bpy.types.Operator):
    """Select objects whose geometry is similar to the active object based on a minimum match percentage."""
    bl_idname = "object.select_similar_geometry"
    bl_label = "Select Similar Geometry"
    bl_options = {'REGISTER', 'UNDO'}

    tol: bpy.props.FloatProperty(
        name="Tolerance",
        description="Distance threshold to consider two vertices as matching (in Blender units)",
        default=0.0001,
        min=0.0,
        max=1.0,
    )

    similarity_threshold: bpy.props.FloatProperty(
        name="Minimum Percentage",
        description="Minimum percentage of vertices from the active object that must be found in the other object",
        default=0.5,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    )

    use_world_space: bpy.props.BoolProperty(
        name="Use World Space",
        description="Compare vertices in world space (more robust with different origins/locations)",
        default=True,
    )

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object selected")
            return {'CANCELLED'}
        if active_obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh")
            return {'CANCELLED'}

        if self.use_world_space:
            ref_verts = get_world_vertices(active_obj)
        else:
            ref_verts = [v.co.copy() for v in active_obj.data.vertices]

        ref_count = len(ref_verts)
        if ref_count == 0:
            self.report({'WARNING'}, "Active object has no vertices")
            return {'CANCELLED'}

        # Deselect all mesh objects
        for obj in context.scene.objects:
            if obj.type == 'MESH':
                obj.select_set(False)
        active_obj.select_set(True)

        selected_count = 0

        # Iterate over all objects in the scene
        for obj in context.scene.objects:
            if obj == active_obj or obj.type != 'MESH':
                continue

            # If they share the same mesh datablock, consider them identical
            if obj.data == active_obj.data:
                obj.select_set(True)
                selected_count += 1
                continue

            # Get the candidate object's vertices
            if self.use_world_space:
                verts = get_world_vertices(obj)
            else:
                verts = [v.co.copy() for v in obj.data.vertices]

            if not verts:
                continue

            # Count how many vertices from the active object have a match in the candidate
            matches = count_vertex_matches(ref_verts, verts, self.tol)

            # Similarity as a percentage of the active object's vertices
            similarity = matches / ref_count

            if similarity >= self.similarity_threshold:
                obj.select_set(True)
                selected_count += 1

        self.report(
            {'INFO'},
            f"Selection complete: {selected_count} similar object(s) found"
        )
        return {'FINISHED'}


def menu_func(self, context):
    self.layout.operator(OBJECT_OT_select_similar_geometry.bl_idname, icon='MESH_CUBE')


def register_keymap():
    """Register the Ctrl+Shift+S shortcut in Object Mode."""
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return

    km = kc.keymaps.new(name="Object Mode", space_type='VIEW_3D')
    kmi = km.keymap_items.new(
        OBJECT_OT_select_similar_geometry.bl_idname,
        type='G',
        value='PRESS',
        ctrl=True,
        shift=True,
    )
    addon_keymaps.append((km, kmi))


def unregister_keymap():
    """Remove the shortcuts registered by this add-on."""
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


def register():
    bpy.utils.register_class(OBJECT_OT_select_similar_geometry)
    bpy.types.VIEW3D_MT_select_object.append(menu_func)
    register_keymap()


def unregister():
    unregister_keymap()
    bpy.types.VIEW3D_MT_select_object.remove(menu_func)
    bpy.utils.unregister_class(OBJECT_OT_select_similar_geometry)


if __name__ == "__main__":
    register()
